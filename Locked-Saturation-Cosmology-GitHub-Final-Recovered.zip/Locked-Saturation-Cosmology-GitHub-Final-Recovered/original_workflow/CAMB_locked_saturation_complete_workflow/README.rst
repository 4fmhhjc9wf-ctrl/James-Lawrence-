===================
CAMB
===================
:CAMB: Code for Anisotropies in the Microwave Background
:Author: Antony Lewis and Anthony Challinor
:Homepage: https://camb.info/
:Paper: `arXiv:2607.14854 <https://arxiv.org/abs/2607.14854>`_
:Changelog: `CHANGELOG.md <CHANGELOG.md>`_

.. image:: https://img.shields.io/pypi/v/camb.svg?style=flat
   :target: https://pypi.python.org/pypi/camb/
.. image:: https://img.shields.io/conda/vn/conda-forge/camb.svg
   :target: https://anaconda.org/conda-forge/camb
.. image:: https://readthedocs.org/projects/camb/badge/?version=latest
   :target: https://camb.readthedocs.io/en/latest
.. image:: https://github.com/cmbant/camb/actions/workflows/tests.yml/badge.svg?branch=master
  :target: https://github.com/cmbant/CAMB/actions
.. image:: https://mybinder.org/badge_logo.svg
  :target: https://mybinder.org/v2/gh/cmbant/CAMB/HEAD?filepath=docs%2FCAMBdemo.ipynb

Description and installation
=============================

CAMB is a cosmology code for calculating cosmological observables, including
CMB, lensing, source count and 21cm angular power spectra, matter power spectra, transfer functions
and background evolution. The code is in Python, with numerical code implemented in fast modern Fortran.

See the `CAMB python example notebook <https://camb.readthedocs.io/en/latest/CAMBdemo.html>`_ for a
quick introduction to how to use the CAMB Python package.

For a standard non-editable installation use::

    pip install camb [--user]

The --user is optional and only required if you don't have write permission to your main python installation.
To install from source, clone from github using::

    git clone --recursive https://github.com/cmbant/CAMB

Then install using::

    pip install -e ./CAMB [--user]

For development, install with dev dependencies and setup pre-commit hooks::

    pip install -e ./CAMB[dev] [--user]
    git config core.hooksPath .githooks

See `CONTRIBUTING.md <CONTRIBUTING.md>`_ for full development setup instructions.

You will need gfortran installed to compile (usually included with gcc by default; ifort and, experimentally,
LLVM flang also work, see `fortran_compilers.rst <docs/source/fortran_compilers.rst>`_).
If you have gfortran installed, "python setup.py make" (and other standard setup commands) will build the Fortran
library on all systems (including Windows without directly using a Makefile).

The python wrapper provides a module called "camb" documented in the Python `CAMB documentation <https://camb.readthedocs.io/en/latest/>`_.

After installation you can also run CAMB from the command line reading parameters from a .ini file, e.g.::

  camb inifiles/planck_2018.ini

To compile the Fortran command-line code run "make camb" in the fortran directory. For full details
see the  `ReadMe <https://camb.info/readme.html>`_.

Citation
===================
You can refer to the papers::

    @article{Lewis:2026mif,
        author = "Lewis, Antony",
        title = "{CAMB v2: cosmological power spectra for high-precision surveys}",
        eprint = "2607.14854",
        archivePrefix = "arXiv",
        primaryClass = "astro-ph.CO",
        month = "7",
        year = "2026"
    }

    @article{Lewis:1999bs,
          author         = "Lewis, Antony and Challinor, Anthony and Lasenby, Anthony",
          title          = "{Efficient computation of CMB anisotropies in closed FRW models}",
          journal        = "Astrophys. J.",
          volume         = "538",
          year           = "2000",
          pages          = "473-476",
          doi            = "10.1086/309179",
          eprint         = "astro-ph/9911177",
          archivePrefix  = "arXiv",
          primaryClass   = "astro-ph",
          SLACcitation   = "%%CITATION = ASTRO-PH/9911177;%%"
    }

and references therein as appropriate.

Branches
=============================

The master branch contains latest changes to the main release version.

There is a test suite, which runs automatically on GitHub actions for new commits and pull requests.
Reference results and test outputs are stored in the `test outputs repository <https://github.com/cmbant/CAMB_test_outputs/>`_. Tests can also be run locally.

To reproduce legacy results, see these tags/branches:

 - *1.6.6* is the last Planck-era precision version, as used by Planck analysis
 - *CAMB_sources* is the old public `CAMB Sources <https://camb.info/sources/>`_ code.
 - *CAMB_v0* is the old Fortran-oriented (gfortran 4.8-compatible) version as used by the Planck 2018 analysis.
 - *rayleigh* includes frequency-dependent Rayleigh scattering
 - *python2* is the last Python 2 compatible version

===================

.. raw:: html

    <a href="https://www.sussex.ac.uk/astronomy/"><img src="https://cdn.cosmologist.info/antony/Sussex_white.svg" style="height:200px" height="200px"></a>
    <a href="https://erc.europa.eu/"><img src="https://cdn.cosmologist.info/antony/ERC_white.svg" style="height:200px" height="200px"></a>
    <a href="https://stfc.ukri.org/"><img src="https://cdn.cosmologist.info/antony/STFC_white.svg" style="height:200px" height="200px"></a>
