from __future__ import annotations

import argparse
import json
import math
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def _ensure_plancklens_paths(root: Path) -> None:
    vendor = root / "vendor" / "plancklens"
    compat = root / "vendor" / "plancklens_compat"
    for path in (compat, vendor):
        if path.exists():
            sys.path.insert(0, str(path))


def _dl_to_cl(frame: pd.DataFrame, lmax: int) -> dict[str, np.ndarray]:
    ell = frame["ell"].to_numpy(dtype=int)
    if ell.max() < lmax:
        raise ValueError(f"Spectrum ends at ell={ell.max()}, below requested lmax={lmax}.")
    factor = np.zeros_like(ell, dtype=float)
    valid = ell >= 2
    factor[valid] = 2.0 * np.pi / (ell[valid] * (ell[valid] + 1.0))
    result: dict[str, np.ndarray] = {}
    for column, key in (("TT", "tt"), ("EE", "ee"), ("BB", "bb"), ("TE", "te")):
        result[key] = (frame[column].to_numpy(dtype=float) * factor)[: lmax + 1].copy()
    return result


def compute_tt_n0(
    spectrum_path: Path,
    output_path: Path,
    lmax_cmb: int,
    lmax_out: int,
    lmin_cmb: int,
    beam_fwhm_arcmin: float,
    noise_t_uk_arcmin: float,
) -> dict[str, float | int | str]:
    from plancklens import nhl, qresp, utils
    import healpy as hp

    frame = pd.read_csv(spectrum_path)
    cls = _dl_to_cl(frame, lmax_cmb)

    noise_p = noise_t_uk_arcmin * math.sqrt(2.0)
    beam = hp.gauss_beam(beam_fwhm_arcmin / 60.0 / 180.0 * np.pi, lmax=lmax_cmb)
    noise_t = (noise_t_uk_arcmin / 60.0 / 180.0 * np.pi) ** 2 / beam**2
    noise_e = (noise_p / 60.0 / 180.0 * np.pi) ** 2 / beam**2
    noise_b = noise_e.copy()

    data_cls = {
        "tt": cls["tt"] + noise_t,
        "ee": cls["ee"] + noise_e,
        "bb": cls["bb"] + noise_b,
        "te": cls["te"].copy(),
    }
    filters = {key: utils.cli(data_cls[key]) for key in ("tt", "ee", "bb")}
    ivf_cls = {
        "tt": filters["tt"].copy(),
        "ee": filters["ee"].copy(),
        "bb": filters["bb"].copy(),
        "te": data_cls["te"] * filters["tt"] * filters["ee"],
    }
    for collection in (filters, ivf_cls):
        for values in collection.values():
            values[:lmin_cmb] = 0.0

    qe_key = "ptt"
    noise_g, _, _, _ = nhl.get_nhl(
        qe_key,
        qe_key,
        cls,
        ivf_cls,
        lmax_cmb,
        lmax_cmb,
        lmax_out=lmax_out,
    )
    response_g, _, _, _ = qresp.get_response(
        qe_key,
        lmax_cmb,
        "p",
        cls,
        cls,
        filters,
        lmax_qlm=lmax_out,
    )
    n0_phi = utils.cli(response_g**2) * noise_g
    out = pd.DataFrame({"L": np.arange(lmax_out + 1), "N0_phi_phi_TT": n0_phi})
    out.to_csv(output_path, index=False)

    samples = {str(L): float(n0_phi[L]) for L in (8, 20, 40, 80, 120) if L <= lmax_out}
    return {
        "spectrum": str(spectrum_path),
        "output": str(output_path),
        "lmax_cmb": lmax_cmb,
        "lmax_out": lmax_out,
        "lmin_cmb": lmin_cmb,
        "beam_fwhm_arcmin": beam_fwhm_arcmin,
        "noise_t_uk_arcmin": noise_t_uk_arcmin,
        "finite": bool(np.isfinite(n0_phi).all()),
        "samples": samples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run PlanckLens analytic TT reconstruction forecast on CAMB spectra.")
    parser.add_argument("--spectrum", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lmax-cmb", type=int, default=2048)
    parser.add_argument("--lmax-out", type=int, default=400)
    parser.add_argument("--lmin-cmb", type=int, default=100)
    parser.add_argument("--beam-fwhm", type=float, default=6.0)
    parser.add_argument("--noise-t", type=float, default=35.0)
    parser.add_argument("--summary", type=Path)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    _ensure_plancklens_paths(root)
    summary = compute_tt_n0(
        args.spectrum,
        args.output,
        args.lmax_cmb,
        args.lmax_out,
        args.lmin_cmb,
        args.beam_fwhm,
        args.noise_t,
    )
    if args.summary:
        args.summary.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
