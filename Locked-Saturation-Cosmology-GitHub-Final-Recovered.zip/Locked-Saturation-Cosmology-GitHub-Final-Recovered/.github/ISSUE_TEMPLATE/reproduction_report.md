---
name: Reproduction report
about: Report a successful, partial, or failed computational reproduction attempt
title: "[Reproduction] "
labels: reproducibility
---

**Scope attempted**

**Environment**
Operating system, language/compiler, package versions, and hardware if relevant.

**Inputs and commands**

**Observed output**

**Expected output**

**Files or logs**
Attach or link to sufficient information for the result to be checked.
