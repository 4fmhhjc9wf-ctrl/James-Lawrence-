---
name: Mathematical issue
about: Report a suspected derivation, sign, definition, limit, or consistency problem
title: "[Math] "
labels: mathematics
---

**Location**
Page, section, and equation number:

**Issue**
Describe the suspected problem precisely.

**Supporting calculation**
Provide the derivation or counterexample.

**Suggested correction**
Optional.
