---
name: Editorial issue
about: Report grammar, notation drift, duplicated text, numbering, or cross-reference problems
title: "[Editorial] "
labels: editorial
---

**Location**
Page and section:

**Current text or notation**

**Problem**

**Suggested correction**
